import { IUser } from "./store/user";

export const users: IUser[] = [
  {
    name: "Andrei",
    email: "andrei@gmail.com",
    pass: "pass1",
  },
  {
    name: "admin",
    email: "admin",
    pass: "admin",
  },
];
