export const keyBuilder = {
  movies: () => ["movies"],
  movie: (id: number) => ["movie", id],
};
